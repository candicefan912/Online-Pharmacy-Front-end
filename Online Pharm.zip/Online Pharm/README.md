### Init npm
npm install --save --legacy-peer-deps


### Run code
npm start

# Pharmacheutical
