### Init npm

npm i

### Run code
npm start

# Pharmacheutical
