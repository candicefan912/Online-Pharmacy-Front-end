import { Button, Form, Input, Modal } from "antd";
import React, { useState, useRef } from "react";
import Pay from "../../components/pay";
export default function (props) {
  const [isModalVisible, setIsModalVisible] = useState(false);

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const onFinish = (values) => {
    console.log("Success:", values);  
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  const [medication, setMedication] = useState("");
  const [dosage, setDosage] = useState("");
  const [price, setPrice] = useState("");
  return (
    <div className="createOrder">
      <Form
        className="orderForm"
        name="basic"
        labelCol={{
          span: 7,
        }}
        wrapperCol={{
          span: 16,
        }}
        initialValues={{
          remember: true,
        }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Form.Item label="Request medication">
          <Input value={medication} />
        </Form.Item>

        <Form.Item label="Dosage">
          <Input value={dosage} />
        </Form.Item>

        <Form.Item label="Price">
          <Input value={price} />
        </Form.Item>

        <Form.Item
          wrapperCol={{
            offset: 8,
            span: 16,
          }}
        >
          <Button type="primary" onClick={showModal} htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
      <Modal
        title="pay"
        visible={isModalVisible}
        footer={null}
        onCancel={handleCancel}
      >
        <Pay closeModel={handleCancel}></Pay>
      </Modal>
    </div>
  );
}
