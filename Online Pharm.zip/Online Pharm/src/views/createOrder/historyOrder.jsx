import { Radio, Space, Table, Tag } from 'antd';
import { useState } from 'react';
export default function(props){
   
        const columns = [
        {
            title: 'order number',
            dataIndex: 'orderNumber',
            key: 'orderNumber',
            render: (text) => <a>{text}</a>,
        },
        {
            title: 'Medication',
            dataIndex: 'Medication',
            key: 'Medication',
        },
        {
            title: 'Dosage',
            dataIndex: 'Dosage',
            key: 'Dosage',
        },
        {
            title: 'Price',
            dataIndex: 'Price',
            key: 'Price',
        },
        {
            title: 'Date',
            key: 'Date',
            dataIndex:'Date'
        },
        ];
        const data = [
        {
            key: '1',
            orderNumber: 'YB1231234',
            Medication: 32,
            Dosage: '500 milligrams each',
            Price: '$12.98',
            Date:'2022-11-1 11:11:11'
        },
        {
            key: '2',
            orderNumber: 'YB1231234',
            Medication: 42,
            Dosage: '500 milligrams each',
            Price: '$12.98',
            Date:'2022-11-1 11:11:11'
        },
        {
            key: '3',
            orderNumber: 'YB1231234',
            Medication: 32,
            Dosage: '500 milligrams each',
            Price: '$12.98',
            Date:'2022-11-1 11:11:11'
        },
    ];


     const [top, setTop] = useState('topLeft');
  const [bottom, setBottom] = useState('bottomRight');
    
    return (
        <div className="historyOrder">
           <Table
                className='historyTable'
                columns={columns}
                pagination={{
                position: [bottom],
                }}
                dataSource={data}
            />
        </div>
    )
}