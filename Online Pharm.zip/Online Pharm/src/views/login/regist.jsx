import React,{useState,useRef} from 'react'
import account from '../../images/account.png'
import passwordicon from '../../images/password.png'
import emailicon from '../../images/email.png'
import { useImperativeHandle,forwardRef } from 'react'

 function Regist(props,ref){
   
    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [gender, setGender] = useState('')
    const [datebirth, setDatebirth] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [click, setClick] = useState(true)
    const registing = ()=>{
        if (click) {
            setClick(false)
            if (firstName.trim() === '') {
                props.setTipText('First Name null')
                return false
            }
            if (lastName.trim() === '') {
                props.setTipText('Last Name null')
                return false
            }
            if (gender.trim() === '') {
                props.setTipText('Gender null')
                return false
            }
            if (datebirth.trim() === '') {
                props.setTipText('Date of birth null')
                return false
            }
            if (email.trim() === '') {
                props.setTipText('Email null')
                return false
            }
            if (password.trim() === '') {
                props.setTipText('password null')
                return false
            }
            //注册接口
            console.log('注册参数',firstName,lastName, gender,datebirth,email,password)
            // registRequest()
            props.closeRegist({firstName,lastName, gender,datebirth,email,password})
        }
    }
    const getFirstName = event=>{
        setFirstName(event.target.value)
    }
    const getLastName = event=>{
        setLastName(event.target.value)
    }
    const getGender = event=>{
        setGender(event.target.value)
    }
    const getDatebirth = event=>{
        setDatebirth(event.target.value)
    }
    const getEmail = event=>{
        setEmail(event.target.value)
    }
    const getPassword = event=>{
        setPassword(event.target.value)
    }
     useImperativeHandle(ref, () => ({
        setData: (params) => {
            setClick(true)
        }
    }))

    return <div className="registBox">
        <div className="left"></div>
        <div className="right">
            <div className='loginBox'>
                <div className='title' style={{marginBottom:'20px'}}>Register Account</div>
                <div className='form'>
                    <div className='formItem'>
                        <img src={account} alt="" />
                        <input type="text" value={firstName} onChange={getFirstName}  placeholder='First Name'/>
                    </div>
                    <div className='formItem'>
                        <img src={account} alt="" />
                        <input type="text" value={lastName} onChange={getLastName}  placeholder='Last Name'/>
                    </div>
                    <div className='formItem'>
                        <img src={account} alt="" />
                        <input type="text" value={gender} onChange={getGender}  placeholder='Gender'/>
                    </div>
                    <div className='formItem'>
                        <img src={account} alt="" />
                        <input type="text" value={datebirth} onChange={getDatebirth}  placeholder='Date of Birth'/>
                    </div>
                    <div className='formItem' >
                        <img src={emailicon} alt="" />
                        <input type="text" value={email} onChange={getEmail} placeholder='Email'/>
                    </div>
                    <div className='formItem' >
                        <img src={passwordicon} style={{marginLeft:'29px'}} alt="" />
                        <input type="text" value={password} onChange={getPassword} placeholder='Set Password'/>
                    </div>
                </div>
                <div className='signIn' style={{marginTop:'20px'}}>
                    <button onClick={registing}>Regist</button>
                </div>
                </div>
        </div>
    </div>
}


export default forwardRef(Regist)