
import axios from "axios"
import { resetAction } from "../redux/actions/user"
import { store } from "../redux/store"

// const baseURL = process.env.NODE_ENV === 'development' ? 'https://open-im-test.rentsoft.cn' : 'https://open-im-online.rentsoft.cn'
const baseURL = process.env.NODE_ENV === 'development' ? 'http://1.117.152.119:8000/cms' : 'http://1.117.152.119:8000/cms'


const service = axios.create({
  baseURL,
  // timeout: 15000, 
})

// Request
service.interceptors.request.use(config => {
  config.headers['token'] = store.getState().user.token
  return config
})

// Response
service.interceptors.response.use(response => {
  if (response.status >= 200 && response.status < 300) {
    // console.log(response)
    const {errCode, errMsg, data} = response.data
    if (errCode === 0) {
      return data
    }

    // token error
    if (errCode === 700) {
      store.dispatch(resetAction())
      return
    }


    // port error
    const err = new Error('port error...')
    err.error = response.data
    return Promise.reject(err)
  }
})

export default service
