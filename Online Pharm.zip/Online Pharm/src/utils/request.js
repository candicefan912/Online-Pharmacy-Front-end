
import axios from "axios"
import { resetAction } from "../redux/actions/user"
import { store } from "../redux/store"
const baseURL = process.env.NODE_ENV === 'development' ? 'http://1.117.152.119:8000/cms' : 'http://1.117.152.119:8000/cms' //本地
//const baseURL = process.env.NODE_ENV === 'development' ? 'http://36.110.20.92:8000/api/' : 'http://36.110.20.92:8000/api/'      //线上


const service = axios.create({
  baseURL,
  timeout: 20000, // 20秒
})

// Request
service.interceptors.request.use(config => {
  config.headers['token'] = store.getState().user.token
  return config
})

// Response
service.interceptors.response.use(response => {
  if (response.status >= 200 && response.status < 300) {
    const {code,errCode, data} = response.data
    if (code === 0 || errCode === 0) {
      return data
    }

    // token error
    if (code === 700) {
      store.dispatch(resetAction())
      return
    }


    // port error
    const err = new Error('port error...')
    err.error = response.data
    return Promise.reject(err)
  }

  console.log('response',response)
  if(response.code==0){
    return response.data
  }
})

export default service
