/*public param*/

  /**
   * 
   * @param {*} ele 
   * @param {*} click 
   * @param {*} second defalt 2 sec
   */
export const show = (ele,click, second = 2) => {
  ele.current.style.display = 'block'
    const time = setTimeout(() => {
      ele.current.style.display = 'none'
      click && click(true)
      clearTimeout(time)
    },second * 1000)
}

