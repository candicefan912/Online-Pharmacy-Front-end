export const LOGIN_SUCCESS = 'login-success' 
export const LOGOUT_SUCCESS = 'logout-success' 
export const USERINFO_RESET = 'userInfo-reset' 