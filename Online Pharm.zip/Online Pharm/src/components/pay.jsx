import { Button, Form, Input, Modal, message, Select } from "antd";
import React, {useState, useRef} from 'react'
const { Option } = Select;
export default function(props){
  const onFinish = (values) => {
    console.log("Success:", values);
  };

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  const [medication, setMedication] = useState("");
  const [dosage, setDosage] = useState("");
  const [price, setPrice] = useState("");
  const confirmPayment = ()=>{
    message.info("pay success");
    props.closeModel()
  }

  const handleSelect = (value) => {
    console.log(`selected ${value}`);
  };
    return (
      <div className="pay">
        <Form
          name="basic"
          labelCol={{
            span: 5,
          }}
          wrapperCol={{
            span: 16,
          }}
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
        >
          <Form.Item label="Card type">
            <Select
              defaultValue="Credit"
              style={{
                width: 120,
              }}
              onChange={handleSelect}
            >
              <Option value="Credit">Credit</Option>
              <Option value="Debit">Debit</Option>
            </Select>
          </Form.Item>

          <Form.Item label="Card Number">
            <Input value={medication} />
          </Form.Item>

          <Form.Item label="Name">
            <Input value={dosage} />
          </Form.Item>

          <Form.Item label="CVV">
            <Input value={price} />
          </Form.Item>

          <Form.Item
            wrapperCol={{
              offset: 8,
              span: 16,
            }}
          >
            <Button type="primary" onClick={confirmPayment} htmlType="submit">
              Confirm Payment
            </Button>
          </Form.Item>
        </Form>
      </div>
    );
}