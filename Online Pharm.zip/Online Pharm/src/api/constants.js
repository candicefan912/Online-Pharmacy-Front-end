const API = {

  LOGIN_LOGIN: '/admin/login',
}

export default API

export const OBJECTSTORAGE= "minio"