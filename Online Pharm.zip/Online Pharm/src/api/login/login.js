/* Login request */
import API from '../constants'
import request from '../../utils/request'

export const userLogin = (name, password) => request({
  url: API.LOGIN_LOGIN,
  method: 'POST',
  data: {
    admin_name: name,
    secret: password,
  }
})